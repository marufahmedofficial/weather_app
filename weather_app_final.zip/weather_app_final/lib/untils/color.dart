import 'package:flutter/material.dart';

const Color cardColor = Color(0xff08677D);
const Color btnColor = Color.fromARGB(255, 28, 122, 143);
const Color iconColor = Colors.white;
const Color txtColor = Colors.white;