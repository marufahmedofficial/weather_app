// ignore_for_file: constant_identifier_names

const String weather_api_key = '308524ef8bbf12ef43fa6562621806bb';
const String celsius = 'C';
const String fahrenheit = 'F';
const String metric = 'metric';
const String imperial = 'imperial';
const String degree = '\u00B0';
const String iconPrefix = 'https://openweathermap.org/img/wn/';
const String iconSuffix = '@2x.png';

const cities = [
  'Arizona',
  'Athens',
  'Berlin',
  'Bangkok',
  'Canberra',
  'Chitagong',
  'Dhaka',
  'Delhi',
  'Ecatepec',
  'Florida',
  'Faridpur',
  'Feni',
  'Gazipur',
  'Hanoy',
  'London',
  'Sydney',
  'New York',
  'Tokio',
  'Morokko',
];
