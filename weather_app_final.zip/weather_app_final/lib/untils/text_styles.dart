import 'package:flutter/material.dart';

const txtTempBig60 = TextStyle(
  fontSize: 60,
  color: Colors.white
);

const txtAddress20 = TextStyle(
    fontSize: 20,
    color: Colors.white,
    fontWeight: FontWeight.bold,
);

const txtDateHeader16 = TextStyle(
    fontSize: 16,
    color: Colors.white,
    fontWeight: FontWeight.bold
);

const txtNormal16 = TextStyle(
    fontSize: 16,
    color: Colors.white
);

const txtNormal16W = TextStyle(
    fontSize: 18,
    color: Colors.white
);

const txtNormal14 = TextStyle(
    fontSize: 14,
    color: Colors.white
);

const txtNormal14B = TextStyle(
    fontSize: 14,
    color: Colors.white,
    fontWeight: FontWeight.bold
);

const txtNormal15 = TextStyle(
    fontSize: 15,
    color: Colors.white,
    fontWeight: FontWeight.bold
);


